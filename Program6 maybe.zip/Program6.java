package Program5;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.Queue;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Random;

public class Program6 {
    public static void main (String[] args) {
    	//Queue<Customer> customerQueue = new LinkedList<>();
        CustomerQueue customerQueue = new CustomerQueue(); // Use your custom queue

    	Random random = new Random(); 

        for (int i = 0; i < 10; i++) {
            String name = "Aysha Rida Puthan Veettil" + (i+1);
            String customerID = "ARPV" + (i+1);
            
        	boolean isChecking = random.nextBoolean();  // Randomly decide between Checking or Saving
            ACCOUNT account;
            if (isChecking) {
                account = Checking.createCheckingAccount(random, i);
            } else {
                account = Saving.createSavingAccount(random, i);
            }
            Customer customer = new Customer(name , customerID , account);
            customerQueue.enqueue(customer); // Use enqueue method from your custom queue
            //customerQueue.add(customer);
        }
        serializeQueue(customerQueue, "Customers.txt");
    }
        
        public static <T extends Serializable>void serializeQueue(CustomerQueue customerQueue, String fileName){
	try (FileOutputStream fos = new FileOutputStream(fileName);
			ObjectOutputStream oos= new ObjectOutputStream(fos)){
		while(!customerQueue.isEmpty()) {
            oos.writeObject(customerQueue.dequeue()); // Use dequeue method from your custom queue
			//oos.writeObject(queue.poll());
		}
		System.out.println(fileName+" has been saved.");
	} catch (IOException e) {
		e.printStackTrace();
		}
    }
}
        