package Program5;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
public class Stack<T extends Serializable> {
    protected ArrayList<T> stack;
 
    public Stack() {
        stack = new ArrayList<>();
    }
 
    public void push(T item) {
        stack.add(item);
    }
 
    public T pop() {
        if (!isEmpty()) {
            return stack.remove(stack.size() - 1);
        }
        return null;
    }
 
    public boolean isEmpty() {
        return stack.isEmpty();
    }
 
    public int size() {
        return stack.size();
    }
 
    public ArrayList<T> getStack() {
        return stack;
    }
}