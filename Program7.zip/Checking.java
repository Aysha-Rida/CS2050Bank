package Program7;
import java.util.Random;

public class Checking extends ACCOUNT {
    public Checking(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    public static Checking createCheckingAccount(Random random, int id) {
        return new Checking("CHK" + id, random.nextDouble() * 1000); // Random initial balance
    }
}