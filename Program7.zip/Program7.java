package Program7;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Random;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class Program7 {
    public static void main(String[] args) throws FileNotFoundException, IOException {
    	LinkedListQueue LinkedListQueue = new LinkedListQueue();
        AccountStack<ACCOUNT> accountStack = new AccountStack<>();
        Random random = new Random();

        // Create accounts and push them onto the stack
        for (int i = 1; i <= 10; i++) {
            boolean isChecking = random.nextBoolean(); // Randomly decide between Checking or Saving
            ACCOUNT account;
            if (isChecking) {
                account = Checking.createCheckingAccount(random, i);
            } else {
                account = Saving.createSavingAccount(random, i);
            }
            accountStack.push(account);
        }

        // Create customers and enqueue them
        for (int i = 1; i <= 10; i++) {
            Customer customer = new Customer("C" + i, "Customer_" + i, null);
            LinkedListQueue.add(customer);
        }

        // Run the simulation 30 times
        for (int i = 0; i < 30; i++) {
            Customer currentCustomer = LinkedListQueue.poll(); // Take the first customer off the queue
            if (currentCustomer.getAccount() == null && !accountStack.isEmpty()) { // Check if customer has an account
                currentCustomer.setAccount(accountStack.pop()); // Assign an account
            }

            // Generate a random transaction amount
            double transactionAmount = random.nextDouble() * 100; // Random amount
            boolean isPositive = random.nextBoolean(); // Random positive or negative
            ACCOUNT account = currentCustomer.getAccount();
            if (isPositive) {
                account.setBalance(account.getBalance() + transactionAmount); // Add to balance
            } else {
                account.setBalance(account.getBalance() - transactionAmount); // Subtract from balance
            }

            LinkedListQueue.add(currentCustomer);
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Customers.txt"))) {
            while (!LinkedListQueue.isEmpty()) {
                Customer customer = LinkedListQueue.poll(); // Retrieve and remove the head of the queue
                ACCOUNT account = customer.getAccount();
                if (account != null) {
                    String details = "Customer ID: " + customer.getCustomerID() +
                                     ", Name: " + customer.getName() +
                                     ", Account Type: " + (account instanceof Checking ? "Checking" : "Saving") +
                                     ", Account Number: " + account.getAccountNumber() +
                                     ", Balance: $" + String.format("%.2f", account.getBalance());
                    System.out.println(details); // Print to console
                    writer.write(details); // Write to file
                    writer.newLine(); // Add a new line
                }
            }
        }
        // Serialize the customer queue
        try (FileOutputStream fos = new FileOutputStream("Customers.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(LinkedListQueue);
            System.out.println("Customers have been saved.");
        }
    }
}