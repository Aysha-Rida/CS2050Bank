package Program7;

import java.util.Random;

public class Saving extends ACCOUNT {
    public Saving(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    public static Saving createSavingAccount(Random random, int id) {
        return new Saving("SAV" + id, random.nextDouble() * 1000); // Random initial balance
    }
}