package Program7;
import java.io.Serializable;

public class CustomerQueue<T extends Serializable> {
	   private Node<T> front;
	   private Node<T> rear;

	    private static class Node<T> {
	        T data;
	        Node<T> next;

	        Node(T data) {
	            this.data = data;
	            this.next = null;
	        }
	    }

	    public CustomerQueue() {
	        front = null;
	        rear = null;
	    }

	    public void enqueue(T item) {
	        Node<T> newNode = new Node<>(item);
	        if (rear != null) {
	            rear.next = newNode;
	        }
	        rear = newNode;
	        if (front == null) {
	            front = rear;
	        }
	    }

	    public T dequeue() {
	        if (front == null) {
	            return null; // or throw an exception
	        }
	        T data = front.data;
	        front = front.next;
	        if (front == null) {
	            rear = null;
	        }
	        return data;
	    }

	    public boolean isEmpty() {
	        return front == null;
	    }
	}