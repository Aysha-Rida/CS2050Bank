package Program7;
import java.io.Serializable;

public abstract class ACCOUNT implements Serializable {
    protected String accountNumber;
    protected double balance;

    public ACCOUNT(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}