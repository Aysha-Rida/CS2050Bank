package Package;

import java.io.*;
import java.util.*;

public class Program8 {

	public static int[] readFile(String fileName) throws IOException {

		List<Integer> list = new ArrayList<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName));
			String line = br.readLine();
			while (line != null) {
				int myInt = Integer.parseInt(line);
				list.add(myInt);
				line = br.readLine();
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return list.stream().mapToInt(i -> i).toArray();
	}

	public static void bubbleSort(int[] arr) {

		int n = arr.length;

		for (int i = 0; i < n - 1; i++) {
			for (int j = 0; j < n - i - 1; j++) {
				if (arr[j] > arr[j + 1]) {
					int temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}
			}
		}
	}

	public static void selectionSort(int[] arr) {

		int n = arr.length;
		for (int i = 0; i < n - 1; i++) {
			int minIdx = i;
			for (int j = i + 1; j < n; j++) {
				if (arr[j] < arr[minIdx]) {
					minIdx = j;
				}
			}
			int temp = arr[minIdx];
			arr[minIdx] = arr[i];
			arr[i] = temp;
		}
	}

	public static void insertionSort(int[] arr) {

		int n = arr.length;

		for (int i = 1; i < n; i++) {
			int key = arr[i];
			int j = i - 1;
			while (j >= 0 && arr[j] > key) {
				arr[j + 1] = arr[j];
				j--;
			}
			arr[j + 1] = key;
		}
	}

	public static void writeTimingToFile(String fileName, String timing) {

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName, true))) {
			bw.write(timing);
			bw.newLine();
		} catch (IOException e) {
			System.out.println("Error writing to file " + fileName + ": " + e.getMessage());
		}
	}

	private static void arrayListSort(List<Integer> arrayList) {

		for (int i = 1; i < arrayList.size(); i++) {
			int key = arrayList.get(i);
			int j = i - 1;
			while (j >= 0 && arrayList.get(j) > key) {
				arrayList.set(j + 1, arrayList.get(j));
				j--;
			}
			arrayList.set(j + 1, key);
		}
	}

	public static void main(String[] args) {

		String[] fileNames = { "big1m.txt", "big2m.txt", "big3m.txt", "big4m.txt", "big5m.txt" };
		String timingFileName = "Program8.txt";
		int[] sortedArray = null;

		for (String fileName : fileNames) {
			try {
				int[] array = readFile(fileName);

				if (!fileName.equals("big5m.txt")) {
					int[] bubbleArr = array.clone();
					long startTimeBubble = System.nanoTime();
					bubbleSort(bubbleArr);
					long endTimeBubble = System.nanoTime();
					double durationBubble = (endTimeBubble - startTimeBubble) / 1_000_000_000.0; // convert to seconds
					String bubbleTiming = String.format("Bubble sort on %s: %.6f s", fileName, durationBubble);
					System.out.println(bubbleTiming);
					writeTimingToFile(timingFileName, bubbleTiming);

				} else {
					sortedArray = array;
				}

				int[] insertionArr = array.clone();
				long startTimeInsertion = System.nanoTime();
				insertionSort(insertionArr);
				long endTimeInsertion = System.nanoTime();
				double durationInsertion = (endTimeInsertion - startTimeInsertion) / 1_000_000_000.0; // convert to
																										// seconds
				String insertionTiming = String.format("Insertion sort on %s: %.6f s", fileName, durationInsertion);
				System.out.println(insertionTiming);
				writeTimingToFile(timingFileName, insertionTiming);

				int[] selectionArr = array.clone();
				long startTimeSelection = System.nanoTime();
				selectionSort(selectionArr);
				long endTimeSelection = System.nanoTime();
				double durationSelection = (endTimeSelection - startTimeSelection) / 1_000_000_000.0; // convert to
																										// seconds
				String selectionTiming = String.format("Selection sort on %s: %.6f s", fileName, durationSelection);
				System.out.println(selectionTiming);
				writeTimingToFile(timingFileName, selectionTiming);

				if (fileName.equals("big5m.txt")) {

					int[] selectionArr1 = sortedArray.clone();
					long startTimeS = System.nanoTime();
					selectionSort(selectionArr1);
					long endTimeS = System.nanoTime();
					double durationS = (endTimeS - startTimeS) / 1_000_000_000.0; // convert to seconds
					String selectionTiming1 = String.format("Selection sort on already sorted array: %.6f s",
							+durationS);
					System.out.println(selectionTiming1);
					writeTimingToFile(timingFileName, selectionTiming1);

					insertionArr = sortedArray.clone();
					long startTimeI = System.nanoTime();
					insertionSort(insertionArr);
					long endTimeI = System.nanoTime();
					double durationI = (endTimeI - startTimeI) / 1_000_000_000.0; // convert to seconds
					String insertionTiming1 = String.format("Insertion sort on already sorted array: %.6f s",
							durationI);
					System.out.println(insertionTiming1);
					writeTimingToFile(timingFileName, insertionTiming1);

					List<Integer> arrayList = new ArrayList<>();
					for (int num : sortedArray) {
						arrayList.add(num);
					}
					long startTimeList = System.nanoTime();
					arrayListSort(arrayList);
					long endTimeList = System.nanoTime();
					double durationList = (endTimeList - startTimeList) / 1_000_000_000.0; // convert to seconds
					String arrayListTiming = String.format("Array List sort on big5m.txt: %.6f s", durationList);
					System.out.println(arrayListTiming);
					writeTimingToFile(timingFileName, arrayListTiming);
				}
			} catch (IOException e) {
				System.out.println("Error reading file " + fileName + ": " + e.getMessage());
			}
		}
	}
}