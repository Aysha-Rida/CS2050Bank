package Program5;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.Queue;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Random;
import java.util.Stack;

public class Program6 {
    public static void main (String[] args) {
    	Queue<Customer> customerQueue = new LinkedList<>();
        Random random = new Random(); 

        for (int i = 0; i < 10; i++) {
            String name = "Aysha Rida Puthan Veettil" + (i+1);
            String customerID = "ARPV" + (i+1);
            
        	boolean isChecking = random.nextBoolean();  // Randomly decide between Checking or Saving
            ACCOUNT account;
            if (isChecking) {
                account = Checking.createCheckingAccount(random, i);
            } else {
                account = Saving.createSavingAccount(random, i);
            }
            Customer customer = new Customer(name + i, customerID , account);
            customerQueue.add(customer);
        }
        serializeQueue(customerQueue, "Customers.txt");
    }
        
        public static <T extends Serializable>void serializeQueue(Queue<T>queue, String fileName){
	try (FileOutputStream fos = new FileOutputStream(fileName);
			ObjectOutputStream oos= new ObjectOutputStream(fos)){
		while(!queue.isEmpty()) {
			oos.writeObject(queue.poll());
		}
		System.out.println(fileName+" has been saved.");
	} catch (IOException e) {
		e.printStackTrace();
		}
    }
}
        